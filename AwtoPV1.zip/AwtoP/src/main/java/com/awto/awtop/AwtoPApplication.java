package com.awto.awtop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwtoPApplication {

    public static void main(String[] args) {
        SpringApplication.run(AwtoPApplication.class, args);
    }

}
