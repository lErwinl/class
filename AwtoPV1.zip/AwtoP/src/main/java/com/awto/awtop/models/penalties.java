package com.awto.awtop.models;

public class penalties {
    private int CitizenId;
    private String reason;

    // Getter and Setter
    public int getCitizenId() {
        return CitizenId;
    }

    public void setCitizenId(int citizenId) {
        CitizenId = citizenId;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}
