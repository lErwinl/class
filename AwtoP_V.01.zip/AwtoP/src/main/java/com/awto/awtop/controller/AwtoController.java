package com.awto.awtop.controller;


import com.awto.awtop.models.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class AwtoController {

    @Autowired
    private Person person;

    // Getter
    @RequestMapping("/citizens/{id}")
    public Person person() {
        return person;
    }

    @GetMapping("/person")
    public ResponseEntity fetchPersons () {
        return new ResponseEntity(HttpStatus.OK);

    }

    // Post Methods OK
    @PostMapping( "/citizens")
    public String createcitizen (@RequestBody Person person){
        return person.getName();
    }

    // Get Methods


    @DeleteMapping("/person/{id}/")
    public ResponseEntity deletePerson(@PathVariable("id") int id){
        return new ResponseEntity(HttpStatus.OK);
    }


}
